import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule, NgIf } from '@angular/common';
import { DataService } from '../../../services/data.service';
import { BrowserModule } from '@angular/platform-browser';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HttpClient, HttpEventType, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-student-application',
  imports: [
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    NgIf,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatSlideToggleModule,
    MatFormFieldModule,
    MatIconModule,
    MatSnackBarModule,
    MatTooltipModule,
  ],
  templateUrl: './student-application.component.html',
  styleUrls: ['./student-application.component.scss'],
})
export class StudentApplicationComponent implements OnInit {
  studentApplicationForm!: FormGroup;
  provinces = [
    'Eastern Cape',
    'Free State',
    'Gauteng',
    'KwaZulu-Natal',
    'Limpopo',
    'Mpumalanga',
    'North West',
    'Northern Cape',
    'Western Cape',
  ];
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  private initForm(): void {
    this.studentApplicationForm = this.fb.group({
      // Province Selection
      province: ['', Validators.required],

      // Section A: Personal Information
      title: [
        '',
        [
          Validators.required,
          Validators.pattern(/^(Mr|Mrs|Ms|Mx|Rev|Hon|Sir|Madam)$/),
        ],
      ],
      initials: [
        '',
        [
          Validators.required,
          Validators.maxLength(6),
          Validators.pattern(/^[A-Z]+$/),
        ],
      ],
      firstNames: [
        '',
        [Validators.required, Validators.pattern(/^[A-Za-z ]+$/)],
      ],
      surname: ['', [Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      studentNumber: ['', [Validators.required, Validators.pattern(/^\d{8}$/)]],
      levelOfStudy: [
        '',
        [Validators.required, Validators.min(1), Validators.max(4)],
      ],
      race: ['', Validators.required],
      gender: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.email]],
      physicalAddress: [
        '',
        [Validators.required, Validators.pattern(/^[A-Za-z0-9 ,.-]+$/)],
      ],
      cellPhoneNumber: [
        '',
        [Validators.required, Validators.pattern(/^\d{10,13}$/)],
      ],
      homeTown: ['', [Validators.required, Validators.pattern(/^[A-Za-z ]+$/)]],

      // Section B: Preferred Area of WIL Placement
      institutionName: ['', Validators.required],
      townSituated: ['', Validators.required],
      contactPerson: ['', Validators.required],
      contactEmail: ['', [Validators.required, Validators.email]],
      telephoneNumber: [
        '',
        [Validators.required, Validators.pattern(/^\d{10,13}$/)],
      ],
      contactCellPhone: [
        '',
        [Validators.required, Validators.pattern(/^\d{10,13}$/)],
      ],

      // Section C: Declaration
      declarationInfo1: [false, Validators.requiredTrue],
      declarationInfo2: [false, Validators.requiredTrue],
      declarationInfo3: [false, Validators.requiredTrue],

      // File Uploads
      signatureImage: [null, Validators.required],
      idDocument: [null, Validators.required],
      cvDocument: [null, Validators.required],
    });
  }

  onSubmit(): void {
    if (this.studentApplicationForm.invalid || this.isSubmitting) {
      this.handleFormErrors();
      return;
    }

    this.isSubmitting = true;
    const formData = this.prepareFormData();

    this.http.post('/api/submit-wil', formData).subscribe({
      next: () => this.handleSubmissionSuccess(),
      error: (err) => this.handleSubmissionError(err),
    });
  }

  private prepareFormData(): FormData {
    const formData = new FormData();
    const formValue = this.studentApplicationForm.value;

    // Append all non-file fields
    Object.keys(formValue).forEach((key) => {
      if (
        key !== 'signatureImage' &&
        key !== 'idDocument' &&
        key !== 'cvDocument'
      ) {
        formData.append(key, formValue[key]);
      }
    });

    // Append files
    ['signatureImage', 'idDocument', 'cvDocument'].forEach((field) => {
      const file = this.studentApplicationForm.get(field)?.value;
      if (file) formData.append(field, file, file.name);
    });

    return formData;
  }

  private handleFormErrors(): void {
    this.studentApplicationForm.markAllAsTouched();
    this.snackBar.open(
      'Please fill out all required fields correctly.',
      'Close',
      {
        duration: 5000,
        panelClass: ['error-snackbar'],
        verticalPosition: 'top',
      }
    );
  }

  private handleSubmissionSuccess(): void {
    this.isSubmitting = false;
    this.snackBar.open('Application submitted successfully!', 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar'],
      verticalPosition: 'top',
    });
    this.router.navigate(['/dashboard']);
  }

  private handleSubmissionError(error: any): void {
    this.isSubmitting = false;
    console.error('Submission failed:', error);
    this.snackBar.open(
      error.error?.message || 'Submission failed. Please try again.',
      'Close',
      {
        duration: 5000,
        panelClass: ['error-snackbar'],
        verticalPosition: 'top',
      }
    );
  }

  onFileChange(event: Event, fieldName: string): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;

    const file = input.files[0];
    this.studentApplicationForm.get(fieldName)?.setValue(file);
  }

  getErrorMessage(controlName: string): string {
    const control = this.studentApplicationForm.get(controlName);

    if (!control?.errors) return '';

    if (control.hasError('required')) {
      return 'This field is required';
    }

    if (control.hasError('email')) {
      return 'Please enter a valid email address';
    }

    if (control.hasError('pattern')) {
      return this.getPatternErrorMessage(controlName);
    }

    if (control.hasError('min') || control.hasError('max')) {
      return 'Level must be between 1 and 4';
    }

    if (control.hasError('requiredTrue')) {
      return 'You must agree to this declaration';
    }

    return 'Invalid input';
  }

  private getPatternErrorMessage(controlName: string): string {
    switch (controlName) {
      case 'title':
        return 'Must be a valid title';
      case 'initials':
        return 'Uppercase letters only (max 6)';
      case 'surname':
        return 'Letters only';
      case 'firstNames':
      case 'homeTown':
      case 'townSituated':
      case 'contactPerson':
        return 'Letters and spaces only';
      case 'studentNumber':
        return 'Must be 8 digits';
      case 'physicalAddress':
        return 'Invalid address format';
      case 'cellPhoneNumber':
      case 'telephoneNumber':
      case 'contactCellPhone':
        return 'Must be 10-13 digits';
      default:
        return 'Invalid format';
    }
  }

  goBack(): void {
    this.router.navigate(['/student-dashboard']);
  }
}
