export interface LogsheetApprovalRequest {
}
