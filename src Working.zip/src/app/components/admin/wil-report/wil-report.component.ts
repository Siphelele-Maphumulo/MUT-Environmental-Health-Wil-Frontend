import { Component } from '@angular/core';

@Component({
  selector: 'app-wil-report',
  imports: [],
  templateUrl: './wil-report.component.html',
  styleUrl: './wil-report.component.scss'
})
export class WilReportComponent {

}
