import { Routes } from '@angular/router';
import { provideRouter } from '@angular/router';

// Import components
import { StudentDashboardComponent } from './components/student/student-dashboard/student-dashboard.component';
import { LoginComponent } from './components/auth/login/login.component';
import { SignupComponent } from './components/auth/signup/signup.component';
import { HomeComponent } from './components/shared/home/home.component';
import { LogsheetComponent } from './components/student/logsheet/logsheet.component';
import { ContactComponent } from './components/student/contact/contact.component';
import { GuideComponent } from './components/shared/guide/guide.component';
import { CommunicationComponent } from './components/shared/communication/communication.component';
import { BenefitsComponent } from './components/shared/benefits/benefits.component';
import { ProfileComponent } from './components/student/profile/profile.component';
import { ReflectionsComponent } from './components/student/reflections/reflections.component';
import { LogformComponent } from './components/student/logform/logform.component';
import { UserManagementComponent } from './components/admin/user-management/user-management.component';
import { PlacementComponent } from './components/admin/placement/placement.component';
import { EventManagementComponent } from './components/admin/event-management/event-management.component';
import { AuditorsComponent } from './components/HPCSA/auditors/auditors.component';
import { ComplianceReportComponent } from './components/HPCSA/compliance-report/compliance-report.component';
import { StudentLogbookViewerComponent } from './components/HPCSA/student-logbook-viewer/student-logbook-viewer.component';
import { MentorGuideComponent } from './components/mentor/mentor-guide/mentor-guide.component';
import { ClassPageComponent } from './components/admin/class-page/class-page.component';
import { MentorSignupComponent } from './components/mentor/mentor-signup/mentor-signup.component';
import { MentorLoginComponent } from './components/mentor/mentor-login/mentor-login.component';
// import { ApplicationComponent } from './components/student/application/application.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';
import { AgreementComponent } from './components/agreement/agreement.component';
import { StudentApplicationComponent } from './components/student/student-application/student-application.component';
import { UpdateStudentComponent } from './components/student/update-student/update-student.component';
import { UpdateStaffComponent } from './components/update-staff/update-staff.component';
import { MentorProfileComponent } from './components/mentor/mentor-profile/mentor-profile.component';
import { DeclarationReportComponent } from './components/mentor/declaration-report/declaration-report.component';
import { PlacementPerformanceComponent } from './components/mentor/placement-performance/placement-performance.component';
import { DashboardComponent } from './components/student/dashboard/dashboard.component';
import { LogbookComponent } from './components/student/logbook/logbook.component';
import { MentorDashboardComponent } from './components/mentor/mentor-dashboard/mentor-dashboard.component';
import { ApplicationsComponent } from './components/admin/applications/applications.component';
import { PinDialogComponent } from './components/admin/event-management/pin-dialog/pin-dialog.component';
import { GuestComponent } from './components/guest/guest.component';
import { AdminHeaderComponent } from './components/admin/admin-header/admin-header.component';
import { ViewlogsheetsComponent } from './components/admin/viewlogsheets/viewlogsheets.component';
import { StaffLoginComponent } from './components/auth/staff-login/staff-login.component';
import { AuthGuard } from './auth.guard';
import { ConfirmationDialogComponent } from './components/shared/confirmation-dialog/confirmation-dialog.component';
import { UpdateDialogComponent } from './components/shared/update-dialog/update-dialog.component';
import { SignDialogComponent } from './components/admin/sign-dialog/sign-dialog.component';
import { SignLogsheetsComponent } from './components/admin/sign-logsheets/sign-logsheets.component';
import { SignupCodeComponent } from './components/auth/signup/signup-code/signup-code.component';
import { CreateEventCodeComponent } from './components/admin/event-code/event-code.component';
import { UpcomingEventsComponent } from './components/admin/upcoming-events/upcoming-events.component';
import { DeclarationLetterComponent } from './components/admin/declaration-letter/declaration-letter.component';
import { ViewDeclarationLettersComponent } from './components/admin/view-declaration-letters/view-declaration-letters.component';
import { ContactsModalComponent } from './components/contacts-modal/contacts-modal.component';
import { AboutusModalComponent } from './components/aboutus-modal/aboutus-modal.component';
import { GuestEventsComponent } from './components/student/guest-events/guest-events.component';
import { StaffCodesComponent } from './components/admin/staff-codes/staff-codes.component';
import { StaffSignupComponent } from './components/auth/staff-signup/staff-signup.component';
import { StaffSignupCodeComponent } from './components/auth/staff-signup/staff-sigup-code/staff-sigup-code.component';

export const appRoutes: Routes = [
  // Default route
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  // Auth routes
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'staff-signup', component: StaffSignupComponent },
  { path: 'staff-login', component: StaffLoginComponent },
  { path: 'mentor-signup', component: MentorSignupComponent },
  { path: 'mentor-login', component: MentorLoginComponent },
  { path: 'signup/signup-code', component: SignupCodeComponent },
  { path: 'staff-signup/staff-signup-code', component: StaffSignupCodeComponent },

  // Shared routes
  { path: 'home', component: HomeComponent },
  { path: 'guide', component: GuideComponent },
  { path: 'communication', component: CommunicationComponent },
  { path: 'benefits', component: BenefitsComponent },
  { path: 'confirmation-dialog', component: ConfirmationDialogComponent },
  { path: 'update-dialog', component: UpdateDialogComponent },

  // Admin routes
  {
    path: 'admin-dashboard',
    component: AdminDashboardComponent,
    canActivate: [AuthGuard],
  },
  { path: 'sign-dialog', component: SignDialogComponent },
  { path: 'sign-logsheets', component: SignLogsheetsComponent },
  { path: 'event-code', component: CreateEventCodeComponent },
  { path: 'staff-codes', component: StaffCodesComponent },
  { path: 'upcoming-events', component: UpcomingEventsComponent },
  { path: 'declaration-letter', component: DeclarationLetterComponent },
  {
    path: 'view-declaration-letters',
    component: ViewDeclarationLettersComponent,
  },

  // Student routes
  {
    path: 'student-dashboard',
    component: StudentDashboardComponent,
    canActivate: [AuthGuard],
  },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'logsheet', component: LogsheetComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'reflections', component: ReflectionsComponent },
  { path: 'logform', component: LogformComponent },
  { path: 'logbook', component: LogbookComponent },
  { path: 'guest-events', component: GuestEventsComponent },
  { path: 'student-application', component: StudentApplicationComponent },
  { path: 'update-student', component: UpdateStudentComponent },

  { path: 'user-management', component: UserManagementComponent },
  { path: 'placement', component: PlacementComponent },
  { path: 'event-management', component: EventManagementComponent },
  { path: 'class-page', component: ClassPageComponent },
  { path: 'applications', component: ApplicationsComponent },
  { path: 'viewlogsheets', component: ViewlogsheetsComponent },
  { path: 'admin-header', component: AdminHeaderComponent },

  // Mentor routes
  {
    path: 'mentor/mentor-dashboard',
    component: MentorDashboardComponent,
    canActivate: [AuthGuard],
  },
  { path: 'mentor-profile', component: MentorProfileComponent },
  { path: 'declaration-report', component: DeclarationReportComponent },
  { path: 'placement-performance', component: PlacementPerformanceComponent },
  { path: 'mentor-guide', component: MentorGuideComponent },

  // HPCSA routes
  { path: 'auditors', component: AuditorsComponent },
  { path: 'compliance-report', component: ComplianceReportComponent },
  { path: 'student-logbook-viewer', component: StudentLogbookViewerComponent },

  // Miscellaneous routes
  { path: 'agreement', component: AgreementComponent },
  { path: 'guest', component: GuestComponent },
  { path: 'contacts-modal', component: ContactsModalComponent },
  { path: 'aboutus-modal', component: AboutusModalComponent },
  { path: 'event-management/pn-dialog', component: PinDialogComponent },
  { path: 'guest/pn-dialog', component: PinDialogComponent },

  // Fallback route (404)
  { path: '**', redirectTo: '/home' },
];

export const appConfig = [provideRouter(appRoutes)];
