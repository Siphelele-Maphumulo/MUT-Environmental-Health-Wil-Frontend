import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { CommonModule } from '@angular/common';
import { StudentHeaderComponent } from './components/student/student-header/student-header.component';
import { AdminHeaderComponent } from './components/admin/admin-header/admin-header.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `
    <!-- Conditionally display headers based on the current route -->
    <app-header *ngIf="showHeader && !showAdminHeader"></app-header>
    <app-student-header *ngIf="showStudentHeader"></app-student-header>
    <app-admin-header *ngIf="showAdminHeader"></app-admin-header>

    <router-outlet></router-outlet>
    <!-- Required for routing to work -->
    <app-footer *ngIf="showFooter"></app-footer>
  `,
  imports: [
    RouterModule,
    HeaderComponent,
    StudentHeaderComponent,
    AdminHeaderComponent,
    FooterComponent,
    CommonModule,
  ],
})
export class AppComponent implements OnInit {
  title = 'environmental-health-wil-frontend';
  showHeader = true;
  showStudentHeader = false;
  showAdminHeader = false;
  showFooter = true;

  // Define routes for specific headers
  studentHeaderRoutes = [
    '/logsheet',
    '/logbook',
    '/student-application',
    '/profile',
    '/guest-events',
    '/staff-signup',
  ];
  adminHeaderRoutes = [
    '/applications',
    '/viewlogsheets',
    '/event-management',
    '/placement',
    '/event-code',
    '/upcoming-events',
    '/declaration-letter',
    '/view-declaration-letters',
    '/staff-codes',
  ];

  // Define routes where both header and footer should be completely hidden
  hiddenRoutes = [
    '/student-dashboard',
    '/admin-dashboard',
    '/mentor-dashboard',
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Subscribe to router events for checking route changes
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const currentUrl = event.urlAfterRedirects;

        // Check if current route is a hidden route
        const isHiddenRoute = this.hiddenRoutes.some((route) =>
          currentUrl.startsWith(route)
        );
        this.showStudentHeader =
          !isHiddenRoute &&
          this.studentHeaderRoutes.some((route) =>
            currentUrl.startsWith(route)
          );
        this.showAdminHeader =
          !isHiddenRoute &&
          this.adminHeaderRoutes.some((route) => currentUrl.startsWith(route));

        this.showHeader =
          !isHiddenRoute && !this.showStudentHeader && !this.showAdminHeader;
        this.showFooter = !isHiddenRoute;
      }
    });
  }
}
