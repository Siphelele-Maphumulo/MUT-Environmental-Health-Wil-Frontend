import { Component, OnInit } from '@angular/core';
import { DataService } from '../../../services/data.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-logbook',
    templateUrl: './logbook.component.html',
    styleUrls: ['./logbook.component.scss'],
    imports: [CommonModule, MatTableModule, MatFormFieldModule, MatInputModule]
})
export class LogbookComponent implements OnInit {
  dataSource = new MatTableDataSource<any>([]);
  displayedColumns: string[] = ['studentId', 'logDate', 'activities', 'hours', 'situationDescription', 'situationReflection', 'situationInterpretation', 'situationEvaluation'];

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    this.fetchAllLogsheets();
  }

  fetchAllLogsheets(): void {
    this.dataService.getAllLogSheets().subscribe({
      next: (data: any[]) => {
        const formattedData = data.map((sheet: any) => ({
          logDate: sheet.logDate,
          studentNumber: sheet.studentNumber,
          activities: this.formatActivities(sheet),
          totalHours: this.calculateTotalHours(sheet),
          situationDescription: sheet.situationDescription,
          situationReflection: sheet.situationReflection,
          situationInterpretation: sheet.situationInterpretation,
          situationEvaluation: sheet.situationEvaluation,
        }));
        this.dataSource.data = formattedData;
      },
      error: (err: any) => {
        console.error('Failed to fetch log sheets:', err);
      },
    });
  }

  formatActivities(sheet: any): string {
    const activityNames = [
      'Food control',
      'Monitoring water quality and availability',
      'Waste management',
      'General hygiene monitoring',
      'Vector control monitoring',
      'Chemical safety',
      'Noise control',
      'Environmental pollution control (water & air)',
      'Radiation monitoring and control',
      'Health surveillance of premises',
      'Surveillance & prevention of communicable diseases and Malaria control',
      'Port health (air, land and seaports)',
      'Control & monitoring of hazardous substances',
      'Disposal of the dead',
    ];

    return activityNames
      .filter((_, i) => sheet[`activity${i + 1}`])
      .join(', ');
  }

  calculateTotalHours(sheet: any): number {
    let totalHours = 0;
    for (let i = 1; i <= 14; i++) {
      totalHours += sheet[`hours${i}`] || 0;
    }
    return totalHours || 1;
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.dataSource.filterPredicate = (data, filter) => {
      return (
        data.studentNumber.toLowerCase().includes(filter) ||
        data.activities.toLowerCase().includes(filter)
      );
    };
    this.dataSource.filter = filterValue;
  }
}
