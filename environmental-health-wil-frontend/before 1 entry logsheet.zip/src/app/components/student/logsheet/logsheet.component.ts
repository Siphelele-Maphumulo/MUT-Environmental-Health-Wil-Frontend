import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-logsheet',
  templateUrl: './logsheet.component.html',
  styleUrls: ['./logsheet.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
  ],
})
export class LogsheetComponent implements OnInit {
  logSheetForm!: FormGroup;
  submissionMessage: string = '';
  today: string = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
  selectedStudentSignature: File | null = null;

  activities = [
    { name: 'Food Control' },
    { name: 'Monitoring water quality and availability' },
    { name: 'Waste Management' },
    { name: 'General hygiene monitoring' },
    { name: 'Vector control monitoring' },
    { name: 'Chemical safety' },
    { name: 'Noise control Hour' },
    { name: 'Environmental pollution control (water & air)' },
    { name: 'Radiation monitoring and control ' },
    { name: 'Health surveillance of premises' },
    {
      name: 'Surveillance & prevention of communicable diseases and Malaria control ',
    },
    { name: 'Port health (air, land and seaports)' },
    { name: 'Control & monitoring of hazardous substances' },
    { name: 'Disposal of the dead' },
    // { name: 'Facility Audits' },
    // { name: 'Other' },
  ];
  selectedActivitiesCount: any;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.logSheetForm = this.fb.group({
      logDate: [this.today],
      studentNumber: ['', Validators.required],
      description: ['', Validators.required],
      situationDescription: ['', Validators.required],
      situationEvaluation: ['', Validators.required],
      situationInterpretation: ['', Validators.required],
      studentSignature: ['', Validators.required],
      dateStamp: [this.today],
    });

    // Dynamically add activity and hours fields
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;

      this.logSheetForm.addControl(activityKey, this.fb.control(false));
      this.logSheetForm.addControl(
        hoursKey,
        this.fb.control({ value: 0, disabled: true }, [
          Validators.min(0),
          Validators.max(6),
        ])
      );

      // Enable/Disable hours field based on activity checkbox
      this.logSheetForm.get(activityKey)?.valueChanges.subscribe((checked) => {
        const hoursControl = this.logSheetForm.get(hoursKey);
        if (checked) {
          hoursControl?.enable();
        } else {
          hoursControl?.disable();
          hoursControl?.setValue(0); // Reset value when disabled
        }
      });
    }
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedStudentSignature = input.files[0];
      console.log('Selected file:', this.selectedStudentSignature);
    }
  }

  onSubmit(): void {
    if (!this.validateForm()) {
      return; // Stop submission if validation fails
    }

    const formData = new FormData();
    const formValue = this.logSheetForm.value;

    // Convert activities to the format backend expects
    const activitiesArray = [];
    let totalHours = 0;
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey];
      const hours = formValue[hoursKey];

      if (activity) {
        activitiesArray.push({
          activity: this.activities[i - 1].name,
          hours: hours || 0,
        });
        totalHours += hours || 0;
      }
    }

    // Add form data
    formData.append('logDate', formValue.logDate);
    formData.append('studentNumber', formValue.studentNumber);
    formData.append('activities', JSON.stringify(activitiesArray));
    formData.append('description', formValue.description);
    formData.append('situationDescription', formValue.situationDescription);
    formData.append('situationEvaluation', formValue.situationEvaluation);
    formData.append(
      'situationInterpretation',
      formValue.situationInterpretation
    );
    formData.append('dateStamp', formValue.dateStamp);

    // Add files
    if (this.selectedStudentSignature) {
      formData.append('student_signature', this.selectedStudentSignature);
    }

    // Debug: Log FormData contents
    formData.forEach((value, key) => {
      console.log(`${key}:`, value);
    });

    // Submit form data
    this.authService.createLogSheet(formData).subscribe({
      next: (response) => {
        this.snackBar.open('Log sheet submitted successfully!', 'Close', {
          duration: 3000,
        });
        this.resetForm();
      },
      error: (error) => {
        console.error('Submission error:', error);
        this.snackBar.open(
          error.error?.message || 'Failed to submit log sheet',
          'Close',
          { duration: 3000 }
        );
      },
    });
  }

  limitSelection(event: any): void {
    const isChecked = event.target.checked;
    const index = event.target.name.replace('activity', '');
    const hoursControl = this.logSheetForm.get(`hours${index}`);

    if (isChecked) {
      this.selectedActivitiesCount++;
      if (this.selectedActivitiesCount > 6) {
        this.snackBar.open('You can only select up to 6 activities.', 'Close', {
          duration: 3000,
        });
        event.target.checked = false;
        this.selectedActivitiesCount--;
      } else {
        hoursControl?.enable();
      }
    } else {
      this.selectedActivitiesCount--;
      hoursControl?.disable();
    }
  }

  validateForm(): boolean {
    const formValue = this.logSheetForm.value;
    const errors: string[] = [];

    // Validate required fields
    if (!formValue.studentNumber) {
      errors.push('Student number is required.');
    }
    if (!formValue.description) {
      errors.push('Description of WIL activities is required.');
    }
    if (!formValue.situationDescription) {
      errors.push('Situation description is required.');
    }
    if (!formValue.situationEvaluation) {
      errors.push('Situation evaluation is required.');
    }
    if (!formValue.situationInterpretation) {
      errors.push('Situation interpretation is required.');
    }
    if (!this.selectedStudentSignature) {
      errors.push('Student signature is required.');
    }

    // Validate activities
    const selectedActivities = [];
    let totalHours = 0;
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey];
      const hours = formValue[hoursKey];

      if (activity) {
        selectedActivities.push(this.activities[i - 1].name);
        if (!hours || hours <= 0) {
          errors.push(
            `Hours must be allocated for activity "${
              this.activities[i - 1].name
            }".`
          );
        }
        totalHours += hours || 0;
      }
    }

    if (selectedActivities.length === 0) {
      errors.push('At least one activity must be selected.');
    } else if (selectedActivities.length === 1 && totalHours !== 6) {
      errors.push('If only one activity is selected, its hours must equal 6.');
    } else if (totalHours > 6) {
      errors.push('Total hours across all activities must not exceed 6.');
    }

    // Display errors in snackbar
    if (errors.length > 0) {
      this.snackBar.open(errors.join('\n'), 'Close', {
        duration: 5000,
        panelClass: 'error-snackbar',
      });
      return false;
    }

    return true;
  }

  resetForm(): void {
    this.logSheetForm.reset({
      logDate: this.today,
      dateStamp: this.today,
    });
    this.selectedStudentSignature = null;
  }

  goBack(): void {
    window.history.back();
  }
}
