import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-placement',
    imports: [
        MatToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatInputModule,
        MatIconModule,
        MatDividerModule,
        MatFormFieldModule,
        ReactiveFormsModule,
        CommonModule,
    ],
    templateUrl: './placement.component.html',
    styleUrls: ['./placement.component.scss']
})
export class PlacementComponent {
  placementForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.placementForm = this.fb.group({
      student: ['', Validators.required],
      supervisor: ['', Validators.required],
      municipality: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      cellNumber: ['', Validators.required],
      hospital: [''],
      abattoir: [''],
    });
  }

  onSubmit() {
    if (this.placementForm.valid) {
      console.log('Form Submitted', this.placementForm.value);
      // Handle form submission logic here
    } else {
      console.log('Form is invalid');
    }
  }
}
