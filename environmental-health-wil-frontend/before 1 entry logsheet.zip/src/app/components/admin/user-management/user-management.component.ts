import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDividerModule } from '@angular/material/divider';
import { CommonModule } from '@angular/common';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { FormsModule } from '@angular/forms';

interface Learner {
  name: string;
  level: string;
  email: string;
  invitationDate: Date;
  status: string;
  enrollmentDate: Date;
}

@Component({
    selector: 'app-user-management',
    imports: [
        CommonModule,
        MatToolbarModule,
        MatButtonModule,
        MatIconModule,
        MatMenuModule,
        MatTableModule,
        MatPaginatorModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatCardModule,
        MatDividerModule,
        FormsModule,
    ],
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements AfterViewInit {
  displayedColumns: string[] = ['learner', 'level', 'invitationDate', 'status', 'enrollmentDate', 'actions'];

  learners: Learner[] = [
    {
      name: 'Siphelele Maphumulo',
      email: 'djnewseason@gmail.com',
      level: 'Level 1',
      invitationDate: new Date(),
      status: 'enrolled',
      enrollmentDate: new Date(),
    },
    // Additional learners...
  ];

  dataSource = new MatTableDataSource<Learner>(this.learners);

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  years: number[] = [];
  selectedYear: number | null = null;
  selectedView: string = 'all';

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.dataSource.filter = filterValue;
  }

  applyViewFilter(view: string) {
    this.selectedView = view;
    // Implement filtering logic based on the selected view
  }

  applyYearFilter(year: number | null) {
    this.selectedYear = year;
    // Implement filtering logic based on the selected year
  }

  suspendLearner(learner: Learner) {
    console.log(`Suspending learner: ${learner.name}`);
    // Implement suspension logic
  }

  unenrollLearner(learner: Learner) {
    console.log(`Unenrolling learner: ${learner.name}`);
    // Implement unenrollment logic
  }

  constructor() {
    this.initializeYears();
  }

  initializeYears(): void {
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 2000; year--) {
      this.years.push(year);
    }
  }
}
