import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-mentor-dashboard',
    imports: [MatToolbarModule, CommonModule, RouterModule],
    templateUrl: './mentor-dashboard.component.html',
    styleUrls: ['./mentor-dashboard.component.scss']
})
export class MentorDashboardComponent {
  constructor() {
    console.log('Mentor Dashboard Component initialized');
  }

  dashboardCards = [
    { title: 'Applications', icon: 'fa fa-file fa-3x', link: '/student-application' },
    { title: 'Logsheets', icon: 'fa fa-clipboard fa-3x', link: '/logsheet' },
    { title: 'Logbooks', icon: 'fa fa-clock-o fa-3x', link: '/logbooks' },
    { title: 'Activities', icon: 'fa fa-book fa-3x', link: '/activities' },
    { title: 'Organizations', icon: 'fa fa-building fa-3x', link: '/organizations' },
    { title: 'Guest Lectures', icon: 'fa fa-user fa-3x', link: '/guest-lectures' }
  ];
}
