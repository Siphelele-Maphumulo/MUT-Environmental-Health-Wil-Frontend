export interface DailyLogSheet {
}
