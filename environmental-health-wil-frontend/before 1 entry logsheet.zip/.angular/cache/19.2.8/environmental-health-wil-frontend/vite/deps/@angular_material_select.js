import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-LOXYRK3O.js";
import "./chunk-GMNCG6DC.js";
import "./chunk-ILBHSQ77.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-TCROIUWU.js";
import "./chunk-XQMW5KRP.js";
import "./chunk-3ECPATUY.js";
import "./chunk-HRDCGGRL.js";
import "./chunk-YZVAPN5T.js";
import "./chunk-VPTMTB3I.js";
import "./chunk-USVC7SPP.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-DE6WUKIB.js";
import "./chunk-SOU5MWMX.js";
import "./chunk-T7PVLK3N.js";
import "./chunk-P7JSOMGW.js";
import "./chunk-LENI4OHH.js";
import "./chunk-QF2T3UEB.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
