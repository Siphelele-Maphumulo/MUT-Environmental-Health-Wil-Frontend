import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-U2RZN3F2.js";
import "./chunk-3W5WD2FS.js";
import "./chunk-LM5ZI77S.js";
import "./chunk-YCU3A7FK.js";
import "./chunk-74QVTC4T.js";
import "./chunk-IUWV4RXD.js";
import "./chunk-PBDVQB5Z.js";
import "./chunk-JWY3ZB4P.js";
import "./chunk-CL6QYO2W.js";
import "./chunk-KMQ2UEIG.js";
import "./chunk-254EO3N5.js";
import "./chunk-TQKD7TTE.js";
import "./chunk-C2QT4FJE.js";
import "./chunk-WBQSER3X.js";
import "./chunk-TDK5NIWS.js";
import "./chunk-RK6XMIZN.js";
import "./chunk-YHCV7DAQ.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
