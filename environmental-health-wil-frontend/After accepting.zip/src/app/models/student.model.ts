export interface Student {
}
