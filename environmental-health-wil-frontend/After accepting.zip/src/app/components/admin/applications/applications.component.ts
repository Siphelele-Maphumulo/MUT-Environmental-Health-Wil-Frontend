import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';
import { Location } from '@angular/common';
import { Application, StudyLevel } from './application.model';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

// Import Angular Material modules
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SafeUrl } from '@angular/platform-browser';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-applications',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
  ],
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.scss'],
})
export class ApplicationsComponent implements OnInit {
  // API URL for fetching applications
  private apiUrl = 'http://localhost:8080/api/applications';

  // Data and state variables
  applications: Application[] = [];
  filteredApplications: Application[] = [];
  isLoading = false;
  error: string | null = null;

  // Filter controls
  searchStatusControl = new FormControl('');
  searchFirstNameControl = new FormControl('');
  searchSurnameControl = new FormControl('');
  searchStudentNumberControl = new FormControl('');
  searchLevelControl = new FormControl('');
  searchEmailControl = new FormControl('');

  // Columns to display in the table
  displayedColumns: string[] = [
    'first_names',
    'surname',
    'student_number',
    'level_of_study',
    'email_address',
    'contact_cell_phone',
    'municipality_name',
    'town_situated',
    'telephone_number',
    'signature_image',
    'status',
    'id_document',
    'cv_document',
    'actions',
  ];

  isUpdatingStatus: { [key: number]: boolean } = {};

  constructor(
    private http: HttpClient,
    private location: Location,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private authService: AuthService // Inject your AuthService here
  ) {}

  ngOnInit(): void {
    this.loadApplications();
    this.setupFilterListeners();
  }

  /**
   * Maps study level number to a human-readable label.
   */
  getStudyLevelLabel(level: string): string {
    const studyLevelMap: { [key: string]: string } = {
      '1': '1st Year',
      '2': '2nd Year',
      '3': '3rd Year',
      '4': 'Undergraduate',
      '5': 'Postgraduate',
      '6': 'Doctorate',
    };
    return studyLevelMap[level] || 'Extended Study Level';
  }

  /**
   * Fetches applications from the backend API.
   */
  loadApplications(): void {
    this.isLoading = true;
    this.error = null;

    this.http
      .get<Application[]>(this.apiUrl)
      .pipe(
        catchError((err) => {
          this.error = 'Failed to load applications. Please try again later.';
          console.error('API Error:', err);
          return of([]);
        }),
        finalize(() => (this.isLoading = false))
      )
      .subscribe({
        next: (data) => {
          this.applications = data.map((app) => ({
            ...app,
            safeSignatureUrl: this.getSafeUrl(app.signature_image),
            safeIdDocUrl: this.getSafeUrl(app.id_document),
            safeCvUrl: this.getSafeUrl(app.cv_document),
          }));
          this.filteredApplications = [...this.applications];
        },
      });
  }

  /**
   * Sets up listeners for filter changes
   */
  private setupFilterListeners(): void {
    // Text filters with debounce

    this.searchStatusControl.valueChanges.subscribe(() => this.applyFilters());

    this.searchFirstNameControl.valueChanges
      .pipe(debounceTime(300))
      .subscribe(() => this.applyFilters());

    this.searchSurnameControl.valueChanges
      .pipe(debounceTime(300))
      .subscribe(() => this.applyFilters());

    this.searchStudentNumberControl.valueChanges
      .pipe(debounceTime(300))
      .subscribe(() => this.applyFilters());

    this.searchEmailControl.valueChanges
      .pipe(debounceTime(300))
      .subscribe(() => this.applyFilters());

    // Level filter (immediate)
    this.searchLevelControl.valueChanges.subscribe(() => this.applyFilters());
  }

  /**
   * Applies all active filters to the applications list
   */
  applyFilters(): void {
    if (!this.applications) return;

    this.filteredApplications = this.applications.filter((app) => {
      return (
        this.checkFirstNameFilter(app.first_names) &&
        this.checkSurnameFilter(app.surname) &&
        this.checkStudentNumberFilter(app.student_number) &&
        this.checkLevelFilter(app.level_of_study) &&
        this.checkEmailFilter(app.email_address) &&
        this.checkStatusFilter(app.status)
      );
    });
  } // Add this filter check method
  private checkStatusFilter(status: string): boolean {
    const selectedStatus = this.searchStatusControl.value;
    if (!selectedStatus) return true;
    return status === selectedStatus;
  }

  /**
   * Checks if application matches first name filter
   */
  private checkFirstNameFilter(firstName: string): boolean {
    const searchTerm = this.searchFirstNameControl.value?.toLowerCase() || '';
    if (!searchTerm) return true;
    return firstName.toLowerCase().includes(searchTerm);
  }

  /**
   * Checks if application matches surname filter
   */
  private checkSurnameFilter(surname: string): boolean {
    const searchTerm = this.searchSurnameControl.value?.toLowerCase() || '';
    if (!searchTerm) return true;
    return surname.toLowerCase().includes(searchTerm);
  }

  /**
   * Checks if application matches student number filter
   */
  private checkStudentNumberFilter(studentNumber: string): boolean {
    const searchTerm =
      this.searchStudentNumberControl.value?.toLowerCase() || '';
    if (!searchTerm) return true;
    return studentNumber.toLowerCase().includes(searchTerm);
  }

  /**
   * Checks if application matches level filter
   */
  private checkLevelFilter(level: StudyLevel): boolean {
    const selectedLevel = this.searchLevelControl.value;
    if (!selectedLevel) return true;

    // Convert both to string for comparison (adjust based on your enum structure)
    return level.toString() === selectedLevel;
  }

  /**
   * Checks if application matches email filter
   */
  private checkEmailFilter(email: string): boolean {
    const searchTerm = this.searchEmailControl.value?.toLowerCase() || '';
    if (!searchTerm) return true;
    return email.toLowerCase().includes(searchTerm);
  }

  /**
   * Clears all filters
   */
  clearFilters(): void {
    this.searchFirstNameControl.reset('');
    this.searchSurnameControl.reset('');
    this.searchStudentNumberControl.reset('');
    this.searchLevelControl.reset('');
    this.searchEmailControl.reset('');
    this.searchStatusControl.reset('');
  }

  /**
   * View application details
   */
  viewDetails(application: Application): void {
    console.log('Viewing:', application);
  }

  /**
   * Sanitize and return safe URL for displaying signature or image
   */
  getSafeUrl(filename: string): SafeUrl {
    if (!filename) return this.sanitizer.bypassSecurityTrustResourceUrl('');

    const fullUrl = filename.startsWith('http')
      ? filename
      : `http://localhost:8080/${filename}`;

    return this.sanitizer.bypassSecurityTrustResourceUrl(fullUrl);
  }

  downloadDocument(url: string, docType: string): void {
    if (!url) {
      this.showErrorSnackbar('No document URL provided');
      return;
    }

    this.isLoading = true;
    const fullUrl = url.startsWith('http')
      ? url
      : `http://localhost:8080/${url}`;

    this.http
      .get(fullUrl, {
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe({
        next: (response) => {
          if (response.status === 200 && response.body) {
            try {
              const contentType =
                response.headers.get('Content-Type') ||
                this.detectMimeType(url);
              const filename = this.extractFilename(url, docType);

              this.triggerDownload(response.body, contentType, filename);
            } catch (e) {
              console.error('Error preparing download:', e);
              this.showErrorSnackbar('Failed to prepare document for download');
            }
          } else {
            console.warn(
              'Download response received, but with unexpected status:',
              response.status
            );
            this.showErrorSnackbar(
              `Unexpected response while downloading ${docType}`
            );
          }
        },
        error: (err) => {
          console.error(`Error downloading ${docType} document:`, err);
          if (err.status === 404) {
            this.showErrorSnackbar(`${docType} document not found`);
          } else {
            this.showErrorSnackbar(`Failed to download ${docType} document`);
          }
        },
      });
  }

  /**
   * Opens a document in a new tab
   */
  openDocument(url: string): void {
    if (!url) {
      this.showErrorSnackbar('No document URL provided');
      return;
    }

    const fullUrl = url.startsWith('http')
      ? url
      : `http://localhost:8080/${url}`;
    window.open(fullUrl, '_blank', 'noopener,noreferrer');
  }

  /**
   * Navigates back to the previous page.
   */
  goBack(): void {
    this.location.back();
  }

  /**
   * Helper method to trigger file download
   */
  private triggerDownload(
    data: Blob,
    contentType: string,
    filename: string
  ): void {
    const blob = new Blob([data], { type: contentType });
    const downloadUrl = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.style.display = 'none';
    link.href = downloadUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    }, 100);
  }

  /**
   * Extracts filename from URL with fallback
   */
  private extractFilename(url: string, docType: string): string {
    const filename = url.split('/').pop() || `${docType}_document`;
    // Remove any query parameters
    return filename.split('?')[0];
  }

  /**
   * Detects proper MIME type for downloads
   */
  private detectMimeType(url: string): string {
    const extension = url.split('.').pop()?.toLowerCase()?.split('?')[0];
    const extensionMap: Record<string, string> = {
      pdf: 'application/pdf',
      png: 'image/png',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      doc: 'application/msword',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    };
    return extensionMap[extension!] || 'application/octet-stream';
  }

  /**
   * Shows error message in snackbar
   */
  private showErrorSnackbar(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 5000,
      panelClass: ['error-snackbar'],
    });
  }

  // Update updateStatus method
  updateStatus(application: Application, newStatus: string): void {
    const previousStatus = application.status;
    this.isUpdatingStatus[application.id] = true;

    this.authService
      .updateWilApplicationStatus(application.id, newStatus)
      .pipe(
        finalize(() => {
          delete this.isUpdatingStatus[application.id];
        })
      )
      .subscribe({
        next: (response) => {
          application.status = newStatus as 'Pending' | 'Accepted' | 'Rejected';
          this.showSuccessSnackbar(
            response.message || 'Status updated successfully'
          );

          // Optional: Update local data if needed
          const index = this.applications.findIndex(
            (app) => app.id === application.id
          );
          if (index !== -1) {
            this.applications[index].status = newStatus as
              | 'Pending'
              | 'Accepted'
              | 'Rejected';
          }
        },
        error: (error) => {
          console.error('Status update failed:', error);
          application.status = previousStatus;
          this.showErrorSnackbar(
            error.error?.message || error.message || 'Failed to update status'
          );
        },
      });
  }

  private showSuccessSnackbar(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar'],
    });
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'Pending':
        return 'status-pending';
      case 'Accepted':
        return 'status-accepted';
      case 'Rejected':
        return 'status-rejected';
      default:
        return '';
    }
  }
}
function throwError(error: any): any {
  throw new Error('Function not implemented.');
}
