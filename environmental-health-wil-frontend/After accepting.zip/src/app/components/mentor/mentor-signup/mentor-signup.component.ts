import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
  ValidatorFn,
} from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from '../../../services/auth.service';

// Angular Material Modules
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule, NgIf } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-mentor-signup',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    CommonModule,
    NgIf,
    MatSlideToggleModule,
    MatFormFieldModule,
    MatIconModule,
    MatSnackBarModule,
    MatTooltipModule,
  ],
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.scss'],
})
export class MentorSignupComponent implements OnInit {
  signupForm!: FormGroup;
  hide = true;
  hideConfirm = true;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar // Inject MatSnackBar for notifications
  ) {}

  ngOnInit(): void {
    this.signupForm = this.fb.group(
      {
        email: [
          '',
          [Validators.required, Validators.email, this.emailDomainValidator()],
        ],
        title: ['', Validators.required],
        password: ['', [Validators.required, Validators.minLength(7)]],
        confirmPassword: ['', Validators.required],
      },
      { validators: this.passwordMatchValidator }
    );

    // Revalidate confirm password field when password changes
    this.signupForm.get('password')?.valueChanges.subscribe(() => {
      this.signupForm.get('confirmPassword')?.updateValueAndValidity();
    });
  }

  // Custom validator to check if the email ends with @mut.ac.za
  emailDomainValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) return null;
      const domain = value.split('@').pop();
      return domain === 'mut.ac.za' ? null : { pattern: true };
    };
  }

  // Custom validator to ensure passwords match
  passwordMatchValidator(group: AbstractControl): ValidationErrors | null {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit(): void {
    if (this.signupForm.valid) {
      const formData = this.signupForm.value;

      this.authService.signup(formData).subscribe({
        next: () => {
          this.snackBar.open('Signup successful!', 'Close', { duration: 3000 });
          this.router.navigate(['/login']);
        },
        error: (err) => {
          console.error('Signup failed:', err);
          this.snackBar.open('Signup failed. Please try again.', 'Close', {
            duration: 5000,
            panelClass: ['error-snackbar'],
          });
        },
      });
    } else {
      const errors = this.getFormValidationErrors();
      this.snackBar.open(errors.join('\n'), 'Close', {
        duration: 5000,
        panelClass: ['error-snackbar'],
      });
    }
  }

  getFormValidationErrors(): string[] {
    const errors: string[] = [];
    const controls = this.signupForm.controls;

    if (controls['email'].hasError('required')) {
      errors.push('Email is required');
    } else if (controls['email'].hasError('email')) {
      errors.push('Invalid email format');
    } else if (controls['email'].hasError('pattern')) {
      errors.push('Email must end with @mut.ac.za');
    }

    if (controls['title'].hasError('required')) {
      errors.push('Title is required');
    }

    if (controls['password'].hasError('required')) {
      errors.push('Password is required');
    } else if (controls['password'].hasError('minlength')) {
      errors.push('Password must be at least 7 characters');
    }

    if (controls['confirmPassword'].hasError('required')) {
      errors.push('Confirm Password is required');
    }

    if (this.signupForm.hasError('mismatch')) {
      errors.push('Passwords do not match');
    }

    return errors;
  }

  login(): void {
    this.router.navigate(['/login']);
  }
}
