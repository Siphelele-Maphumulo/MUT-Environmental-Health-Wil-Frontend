import { Component } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MatDialogModule,
} from '@angular/material/dialog';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { PinDialogComponent } from './pin-dialog/pin-dialog.component'; // Update this path if needed

@Component({
  selector: 'app-guest',
  standalone: true,
  imports: [
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule, // ✅ Include Snackbar module
    CommonModule,
  ],
  templateUrl: './guest.component.html',
  styleUrls: ['./guest.component.scss'], // Fixed typo here
})
export class GuestComponent {
  selectedFileName: string | null = null;

  constructor(
    private dialog: MatDialog,
    private router: Router,
    private snackBar: MatSnackBar // ✅ Inject Snackbar
  ) {}

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFileName = input.files[0].name;
      console.log('File selected:', input.files[0]);
    }
  }

  openPinDialog(): void {
    const dialogRef = this.dialog.open(PinDialogComponent, {
      width: '300px',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result === '2023') {
          this.router.navigate(['/home']);
        } else {
          this.snackBar.open('Invalid Pin Code', 'Close', {
            duration: 3000,
            panelClass: ['snackbar-error'],
            horizontalPosition: 'center',
            verticalPosition: 'top',
          });
        }
      }
      // Do nothing if cancelled
    });
  }

  goBack() {
    this.router.navigate(['/home']);
  }
}
