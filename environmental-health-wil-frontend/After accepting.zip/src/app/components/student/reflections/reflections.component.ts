import { Component, OnInit } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';

@Component({
    selector: 'app-reflections',
    imports: [
        MatToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatInputModule,
    ],
    templateUrl: './reflections.component.html',
    styleUrl: './reflections.component.scss'
})
export class ReflectionsComponent {
  ngOnInit(): void {
    console.log('Reflections component initialized');
  }
}
