import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';

// Add interface for better type safety
export interface LogSheet {
  id: number;
  date: string;
  hours: number;
  activities: string;
  // Add other properties as needed
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:8080/api'; // Base URL for the API

  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object // Inject PLATFORM_ID
  ) {}

  // Handle API response errors consistently
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      if (error.error?.message) {
        errorMessage = error.error.message;
      }
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }

  // Signup Method
  signup(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/signup`, userData).pipe(
      catchError((error) => {
        if (error.error?.message === 'Email already exists') {
          return throwError(() => new Error('Email already exists'));
        }
        return this.handleError(error);
      })
    );
  }

  // Login Method
  login(credentials: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
      catchError((error) => {
        if (error.error?.message === 'User not found') {
          return throwError(() => new Error('User not found'));
        }
        if (error.error?.message === 'Invalid credentials') {
          return throwError(() => new Error('Invalid credentials'));
        }
        return this.handleError(error);
      })
    );
  }

  // Submit Student Application
  submitStudentApplication(formData: FormData): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/applications`, formData)
      .pipe(catchError(this.handleError));
  }

  // Submit Log Sheet
  createLogSheet(formData: FormData): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/submit-logsheet`, formData)
      .pipe(catchError(this.handleError));
  }

  // Get Logsheets
  getLogsheets(): Observable<any> {
    return this.http
      .get(`${this.apiUrl}/daily-logsheets`)
      .pipe(catchError(this.handleError));
  }

  // Delete Log Sheet
  deleteLogSheet(id: number): Observable<any> {
    return this.http
      .delete(`${this.apiUrl}/delete-logsheets/${id}`, {
        observe: 'response',
      })
      .pipe(catchError(this.handleError));
  }

  // Function to update logsheet (send data to backend)
  // Fetch the existing log sheet data
  getLogsheet(logId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/daily-logsheets/${logId}`);
  }

  // Update the log sheet with the modified data
  updateLogsheets(logId: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/update-logsheets/${logId}`, formData);
  }

  updateLogsheet(logsheetId: number, formData: FormData): Observable<any> {
    return this.http
      .put(`${this.apiUrl}/update-logsheets/${logsheetId}`, formData, {
        observe: 'response',
      })
      .pipe(
        map((response: HttpResponse<any>) => {
          return response.body || { message: 'Updated, but no response body' };
        }),
        catchError(this.handleError)
      );
  }

  // Update the application form with the modified status
  updateWilApplicationStatus(
    applicationId: number,
    status: string
  ): Observable<any> {
    return this.http
      .put<any>(
        `${this.apiUrl}/update-status/${applicationId}`,
        { status },
        { observe: 'response' } // Get full response including status code
      )
      .pipe(
        map((response) => {
          if (response.status === 200) {
            return response.body;
          }
          throw new Error('Unexpected response status');
        }),
        catchError(this.handleError)
      );
  }

  // signLogsheet(logsheetId: number, formData: FormData): Observable<any> {
  //   console.log('FormData before sending:');
  //   formData.forEach((value, key) => {
  //     console.log(key, value);
  //   });

  //   return this.http
  //     .put(`${this.apiUrl}/sign-logsheets/${logsheetId}`, formData, {
  //       observe: 'response',
  //       headers: {
  //         Accept: 'application/json',
  //       },
  //     })
  //     .pipe(
  //       map((response: HttpResponse<any>) => {
  //         return response.body || { message: 'Updated, but no response body' };
  //       }),
  //       catchError((error) => {
  //         console.error('Full error:', error);
  //         return throwError(
  //           () => new Error('Something went wrong; please try again later.')
  //         );
  //       })
  //     );
  // }

  // auth.service.ts
  signLogsheet(logsheetId: number, formData: FormData): Observable<any> {
    return this.http.put(
      `${this.apiUrl}/update-logsheets/${logsheetId}`,
      formData,
      {
        headers: {
          // Remove explicit Content-Type header
          Accept: 'application/json',
        },
      }
    );
  }

  // Logout Method
  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.removeItem('userEmail');
    }
    this.router.navigate(['/home']);
  }

  // Check Authentication Status
  isAuthenticated(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      const userEmail = sessionStorage.getItem('userEmail');
      return !!userEmail;
    }
    return false;
  }

  // Get User Email
  getUserEmail(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('userEmail');
    }
    return null;
  }
}
