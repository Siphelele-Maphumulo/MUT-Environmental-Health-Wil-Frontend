import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-RPEDBJ6O.js";
import "./chunk-6HY46QHC.js";
import "./chunk-LM5ZI77S.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-KLL2TQTW.js";
import "./chunk-M3B3BVGV.js";
import "./chunk-74QVTC4T.js";
import "./chunk-IUWV4RXD.js";
import "./chunk-NHSCF2ZV.js";
import "./chunk-PBDVQB5Z.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-WW254KTR.js";
import "./chunk-D2UKSKCB.js";
import "./chunk-KMQ2UEIG.js";
import "./chunk-XKF4OXGY.js";
import "./chunk-254EO3N5.js";
import "./chunk-TQKD7TTE.js";
import "./chunk-C2QT4FJE.js";
import "./chunk-WBQSER3X.js";
import "./chunk-TDK5NIWS.js";
import "./chunk-RK6XMIZN.js";
import "./chunk-YHCV7DAQ.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
