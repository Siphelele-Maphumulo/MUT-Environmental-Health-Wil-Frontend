import { Student } from './../models/student.model';
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError, map } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';

// Interface definitions for better type safety
interface StatusUpdateResponse {
  success: boolean;
  message: string;
  newStatus: string;
  code?: string;
  changes?: number;
}

// Add these interfaces for better type safety
interface LogSheet {
  message: string;
  data: {
    log_date: string;
    student_number: string;
    activities: Activity[];
  };
}

interface Activity {
  activity: string;
  hours: number;
}

export interface User {
  email: string;
  title: string;
  password: string;
  code: string; // <-- Add this line
}

interface StaffCodeResponse {
  success: boolean;
  message: string;
  data: {
    code: string;
  };
}

export interface StudentUser {
  email: string;
  title: string;
  password: string;
  code: string; // <-- Add this line
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  public apiUrl = 'http://localhost:8080/api'; // Base URL for the API
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Accept: 'application/json',
  });

  constructor(
    private http: HttpClient,
    private router: Router,
    private snackBar: MatSnackBar,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  // Enhanced error handler with detailed logging
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';
    const errorContext = {
      status: error.status,
      url: error.url,
      message: error.message,
      serverMessage: error.error?.message,
    };

    if (error.status === 0) {
      errorMessage = 'Network error: Could not connect to server';
    } else if (error.error instanceof ErrorEvent) {
      errorMessage = `Client-side error: ${error.error.message}`;
    } else {
      errorMessage = error.error?.message || error.message;
    }

    console.error('API Error:', errorContext);
    return throwError(() => ({
      message: errorMessage,
      details: errorContext,
    }));
  }

  // student users
  studentSignup(userData: User): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/student_signup`, userData, {
        headers: this.headers,
      })
      .pipe(catchError(this.handleError));
  }

  // staff users
  staffSignup(userData: User): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/staff_Signup`, userData, { headers: this.headers })
      .pipe(catchError(this.handleError));
  }

  // All users
  signup(userData: User): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/signup`, userData, { headers: this.headers })
      .pipe(catchError(this.handleError));
  }

  studentLogin(credentials: {
    email: string;
    password: string;
  }): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/studentLogin`, credentials, {
        headers: this.headers,
      })
      .pipe(catchError(this.handleError));
  }

  staffLogin(credentials: {
    email: string;
    password: string;
  }): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/staffLogin`, credentials, { headers: this.headers })
      .pipe(catchError(this.handleError));
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.removeItem('userEmail');
    }
    this.router.navigate(['/home']);
  }

  // Application Methods
  submitStudentApplication(formData: FormData): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/applications`, formData)
      .pipe(catchError(this.handleError));
  }

  updateWilApplicationStatus(
    applicationId: number,
    status: 'Pending' | 'Accepted' | 'Rejected'
  ): Observable<StatusUpdateResponse> {
    return this.http
      .put<StatusUpdateResponse>(
        `${this.apiUrl}/update-status/${applicationId}`,
        { status },
        { headers: this.headers }
      )
      .pipe(
        catchError((error: HttpErrorResponse) => {
          console.error('Status update error:', {
            applicationId,
            status,
            statusCode: error.status,
            error: error.error,
          });

          let userMessage = 'Failed to update status';
          if (error.status === 500) {
            userMessage = error.error?.message || 'Server error occurred';
            if (error.error?.errorDetails?.sqlMessage) {
              console.error(
                'MySQL Error:',
                error.error.errorDetails.sqlMessage
              );
            }
          }

          return throwError(() => ({
            message: userMessage,
            details: error.error?.errorDetails,
            statusCode: error.status,
          }));
        })
      );
  }

  // Logsheet Methods
  getLogsheets(): Observable<LogSheet[]> {
    return this.http
      .get<LogSheet[]>(`${this.apiUrl}/daily-logsheets`)
      .pipe(catchError(this.handleError));
  }

  getLogsheet(logId: number): Observable<LogSheet> {
    return this.http
      .get<LogSheet>(`${this.apiUrl}/daily-logsheets/${logId}`)
      .pipe(catchError(this.handleError));
  }

  // Add this new method to your AuthService
  // auth.service.ts
  checkLogsheetExists(
    studentNumber: string,
    logDate: string
  ): Observable<{ exists: boolean }> {
    // Add validation to match backend
    if (!studentNumber || !logDate) {
      return throwError(
        () => new Error('Student number and log date are required')
      );
    }

    return this.http
      .get<{ exists: boolean }>(
        `${this.apiUrl}/check-logsheet/${studentNumber}/${logDate}`,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
          }),
          responseType: 'json' as const, // Explicitly set response type
        }
      )
      .pipe(
        catchError((error) => {
          // Handle different error cases
          if (error.status === 404) {
            return throwError(
              () => new Error('Endpoint not found. Check backend routes.')
            );
          }
          return throwError(() => error);
        })
      );
  }

  // Update your existing createLogSheet method
  createLogSheet(formData: FormData): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/submit-logsheet`, formData)
      .pipe(catchError(this.handleError));
  }

  updateLogsheet(logsheetId: number, formData: FormData): Observable<LogSheet> {
    return this.http
      .put<LogSheet>(
        `${this.apiUrl}/update-logsheets/${logsheetId}`,
        formData,
        {
          observe: 'response',
        }
      )
      .pipe(
        map((response) => {
          if (!response.body) {
            throw new Error('Empty response body');
          }
          return response.body;
        }),
        catchError(this.handleError)
      );
  }

  signLogsheet(logsheetId: number, formData: FormData): Observable<any> {
    return this.http
      .put(`${this.apiUrl}/sign-logsheets/${logsheetId}`, formData, {
        headers: { Accept: 'application/json' },
      })
      .pipe(catchError(this.handleError));
  }

  deleteLogSheet(id: number): Observable<HttpResponse<void>> {
    return this.http
      .delete<void>(`${this.apiUrl}/delete-logsheets/${id}`, {
        observe: 'response', // This tells HttpClient to give us the full HttpResponse
      })
      .pipe(catchError(this.handleError));
  }

  // Utility Methods
  isAuthenticated(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      return !!sessionStorage.getItem('userEmail');
    }
    return false;
  }

  // Get student email
  getUserEmail(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('userEmail');
    }
    return null;
  }

  // Get student number
  getStudentNumber(): string | null {
    const email = this.getUserEmail();
    return email ? email.split('@')[0] : null;
  }

  // Check if signup code is valid
  validateSignupCode(code: string) {
    this.snackBar.open('The code on Auth!' + code, 'Close', {
      duration: 5000,
    });

    return this.http.post(`${this.apiUrl}/validate-signup-code`, { code }).pipe(
      map((response: any) => {
        if (response && typeof response.success === 'boolean') {
          return response.success;
        }
        return false;
      }),
      catchError((error) => {
        console.error('Validation error:', error);
        return of(false);
      })
    );
  }

  // Block signup email if too many failed attempts
  blockSignupEmail(
    email: string
  ): Observable<{ success: boolean; message: string }> {
    return this.http.post(`${this.apiUrl}/block-signup-email`, { email }).pipe(
      map((response: any) => ({
        success: response?.success || false,
        message: response?.message || '',
      })),
      catchError((error) => {
        console.error('Error blocking email:', error);
        return of({
          success: false,
          message: error.error?.message || 'Failed to block email',
        });
      })
    );
  }

  createEventCode(eventCodeData: any): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/create-event-code`, eventCodeData)
      .pipe(
        catchError((error) => {
          console.error('API error:', error);
          return throwError(() => new Error('Event code creation failed'));
        })
      );
  }

  validateEventCode(code: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/validate-event-code`, { code }).pipe(
      catchError((error) => {
        console.error('Validation error:', error);
        return throwError(() => new Error('Validation failed'));
      })
    );
  }

  addGuestLecture(lectureData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/guest-lectures`, lectureData).pipe(
      catchError((error) => {
        console.error('API error:', error);
        return throwError(() => new Error('Submission failed'));
      })
    );
  }

  getGuestLectures(): Observable<any> {
    return this.http.get(`${this.apiUrl}/upcoming-events`).pipe(
      catchError((error) => {
        console.error('API error:', error);
        return throwError(() => new Error('Failed to fetch guest events'));
      })
    );
  }

  deleteGuestLecture(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete-event/${id}`).pipe(
      catchError((error) => {
        console.error('API error:', error);
        return throwError(() => new Error('Failed to delete guest event'));
      })
    );
  }

  submitDeclaration(formData: FormData): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/submit-declaration-letter`, formData)
      .pipe(catchError(this.handleError));
  }

  createStaffCode(staffData: {
    staff_name: string;
    staff_email: string;
  }): Observable<StaffCodeResponse> {
    return this.http
      .post<StaffCodeResponse>(`${this.apiUrl}/staff_codes`, staffData, {
        headers: this.headers,
      })
      .pipe(catchError(this.handleError));
  }

  // Check if signup code is valid
  validateStaffCode(code: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/validate-staff-code`, { code }).pipe(
      map((response: any) => {
        if (response && typeof response.success === 'boolean') {
          return response;
        }
        return { success: false, message: 'Invalid response format' };
      }),
      catchError((error) => {
        console.error('Validation error:', error);
        return of({ success: false, message: 'Error validating staff code' });
      })
    );
  }

  // auth.service.ts
  getLogsheetByDate(studentNumber: string, logDate: string): Observable<any> {
    const formattedDate = new Date(logDate).toISOString().split('T')[0];
    const url = `${this.apiUrl}/get-logsheet/${studentNumber}/${formattedDate}`;

    console.log('Making request to:', url); // Add this for debugging

    return this.http.get(url).pipe(catchError(this.handleError));
  }

  update1Logsheet(formData: FormData): Observable<any> {
    return this.http
      .put(`${this.apiUrl}/update-logsheet`, formData)
      .pipe(catchError(this.handleError));
  }

  getSignatureFile(filename: string): Observable<any> {
    return this.http
      .get(`${this.apiUrl}/signatures/${filename}`, {
        responseType: 'blob',
      })
      .pipe(catchError(this.handleError));
  }
}
