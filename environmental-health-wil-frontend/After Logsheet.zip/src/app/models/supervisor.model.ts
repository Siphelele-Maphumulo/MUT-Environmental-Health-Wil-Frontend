export interface Supervisor {
}
