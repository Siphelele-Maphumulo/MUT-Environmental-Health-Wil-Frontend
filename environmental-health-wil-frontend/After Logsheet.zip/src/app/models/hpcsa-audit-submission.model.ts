export interface HpcsaAuditSubmission {
}
