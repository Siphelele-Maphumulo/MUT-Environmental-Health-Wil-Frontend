import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-logsheet',
  templateUrl: './logsheet.component.html',
  styleUrls: ['./logsheet.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
  ],
})
export class LogsheetComponent implements OnInit {
  logSheetForm!: FormGroup;
  submissionMessage: string = '';
  today: string = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
  selectedStudentSignature: File | null = null;
  studentNumber: string | null = null;
  isFromStudentDashboard: boolean = false;

  activities = [
    { name: 'Food Control' },
    { name: 'Monitoring water quality and availability' },
    { name: 'Waste Management' },
    { name: 'General hygiene monitoring' },
    { name: 'Vector control monitoring' },
    { name: 'Chemical safety' },
    { name: 'Noise control Hour' },
    { name: 'Environmental pollution control (water & air)' },
    { name: 'Radiation monitoring and control ' },
    { name: 'Health surveillance of premises' },
    {
      name: 'Surveillance & prevention of communicable diseases and Malaria control ',
    },
    { name: 'Port health (air, land and seaports)' },
    { name: 'Control & monitoring of hazardous substances' },
    { name: 'Disposal of the dead' },
    // { name: 'Facility Audits' },
    // { name: 'Other' },
  ];
  selectedActivitiesCount: any;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  // logsheet.component.ts
  ngOnInit(): void {
    const navigationState = history.state;
    this.isFromStudentDashboard = navigationState?.from === 'student-dashboard';
    this.studentNumber =
      navigationState?.studentNumber || this.authService.getStudentNumber();

    // Initialize form
    this.initializeForm();

    // Check for existing logsheet immediately
    this.checkExistingLogsheet();
  }

  private initializeForm(): void {
    this.logSheetForm = this.fb.group({
      logDate: [this.today],
      studentNumber: ['', Validators.required],
      description: ['', Validators.required],
      situationDescription: ['', Validators.required],
      situationEvaluation: ['', Validators.required],
      situationInterpretation: ['', Validators.required],
      studentSignature: ['', Validators.required],
      dateStamp: [this.today],
    });

    if (this.studentNumber) {
      this.logSheetForm.get('studentNumber')?.setValue(this.studentNumber);
    }

    // Add activity controls
    for (let i = 1; i <= 14; i++) {
      this.addActivityControls(i);
    }
  }

  private addActivityControls(index: number): void {
    const activityKey = `activity${index}`;
    const hoursKey = `hours${index}`;

    this.logSheetForm.addControl(activityKey, this.fb.control(false));
    this.logSheetForm.addControl(
      hoursKey,
      this.fb.control({ value: 0, disabled: true }, [
        Validators.min(0),
        Validators.max(6),
      ])
    );

    this.logSheetForm.get(activityKey)?.valueChanges.subscribe((checked) => {
      const hoursControl = this.logSheetForm.get(hoursKey);
      checked ? hoursControl?.enable() : hoursControl?.disable();
      if (!checked) hoursControl?.setValue(0);
    });
  }

  private checkExistingLogsheet(): void {
    if (!this.studentNumber) return;

    this.authService
      .checkLogsheetExists(this.studentNumber, this.today)
      .subscribe({
        next: (response) => {
          if (response.exists) {
            this.snackBar.open(
              'Logsheet for today has already been submitted, you can only update the logsheet.',
              'Close',
              { duration: 5000 }
            );
            this.router.navigate(['/update-logsheet'], {
              state: {
                studentNumber: this.studentNumber,
                logDate: this.today,
              },
            });
          }
        },
        error: (error) => {
          console.error('Error checking logsheet:', error);
          this.snackBar.open(
            'Error checking existing logsheet. You may proceed.',
            'Close',
            { duration: 3000 }
          );
        },
      });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedStudentSignature = input.files[0];
      console.log('Selected file:', this.selectedStudentSignature);
    }
  }

  // logsheet.component.ts
  onSubmit(): void {
    if (!this.validateForm()) {
      return; // Stop submission if validation fails
    }

    const formValue = this.logSheetForm.value;
    const studentNumber = formValue.studentNumber;
    const logDate = formValue.logDate;

    // First check if logsheet exists
    this.authService.checkLogsheetExists(studentNumber, logDate).subscribe({
      next: (response) => {
        if (response.exists) {
          this.snackBar.open(
            'You have already submitted a logsheet for today. Please edit the existing one.',
            'Close',
            { duration: 5000, panelClass: 'error-snackbar' }
          );
          return;
        }

        // If doesn't exist, proceed with submission
        this.submitLogsheet();
      },
      error: (error) => {
        console.error('Error checking logsheet:', error);
        this.snackBar.open(
          'Failed to check existing logsheet. Please try again.',
          'Close',
          { duration: 3000 }
        );
      },
    });
  }

  private submitLogsheet(): void {
    const formData = new FormData();
    const formValue = this.logSheetForm.value;

    // Add form data with correct field names (snake_case)
    formData.append('log_date', formValue.logDate);
    formData.append('student_number', formValue.studentNumber);
    formData.append('EHP_HI_Number', 'Not Signed');

    // Add individual activity fields
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey]
        ? this.activities[i - 1].name
        : null;
      const hours = formValue[hoursKey] || null;

      formData.append(activityKey, activity || '');
      formData.append(hoursKey, hours?.toString() || '');
    }

    formData.append('description', formValue.description);
    formData.append('situation_description', formValue.situationDescription);
    formData.append('situation_evaluation', formValue.situationEvaluation);
    formData.append(
      'situation_interpretation',
      formValue.situationInterpretation
    );
    formData.append('date_stamp', formValue.dateStamp);

    // Add files
    if (this.selectedStudentSignature) {
      formData.append('student_signature', this.selectedStudentSignature);
    }

    // Debug: Log FormData contents
    formData.forEach((value, key) => {
      console.log(`${key}:`, value);
    });

    // Submit form data
    this.authService.createLogSheet(formData).subscribe({
      next: (response) => {
        this.snackBar.open('Log sheet submitted successfully!', 'Close', {
          duration: 3000,
        });
        this.resetForm();
      },
      error: (error) => {
        console.error('Submission error:', error);
        this.snackBar.open(
          error.error?.message || 'Failed to submit log sheet',
          'Close',
          { duration: 3000 }
        );
      },
    });
  }

  limitSelection(event: any): void {
    const isChecked = event.target.checked;
    const index = event.target.name.replace('activity', '');
    const hoursControl = this.logSheetForm.get(`hours${index}`);

    if (isChecked) {
      this.selectedActivitiesCount++;
      if (this.selectedActivitiesCount > 6) {
        this.snackBar.open('You can only select up to 6 activities.', 'Close', {
          duration: 3000,
        });
        event.target.checked = false;
        this.selectedActivitiesCount--;
      } else {
        hoursControl?.enable();
      }
    } else {
      this.selectedActivitiesCount--;
      hoursControl?.disable();
    }
  }

  validateForm(): boolean {
    const formValue = this.logSheetForm.value;
    const errors: string[] = [];

    // Validate required fields
    if (!formValue.studentNumber) {
      errors.push('Student number is required.');
    }
    if (!formValue.description) {
      errors.push('Description of WIL activities is required.');
    }
    if (!formValue.situationDescription) {
      errors.push('Situation description is required.');
    }
    if (!formValue.situationEvaluation) {
      errors.push('Situation evaluation is required.');
    }
    if (!formValue.situationInterpretation) {
      errors.push('Situation interpretation is required.');
    }
    if (!this.selectedStudentSignature) {
      errors.push('Student signature is required.');
    }

    // Validate activities
    const selectedActivities = [];
    let totalHours = 0;
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey];
      const hours = formValue[hoursKey];

      if (activity) {
        selectedActivities.push(this.activities[i - 1].name);
        if (!hours || hours <= 0) {
          errors.push(
            `Hours must be allocated for activity "${
              this.activities[i - 1].name
            }".`
          );
        }
        totalHours += hours || 0;
      }
    }

    if (selectedActivities.length === 0) {
      errors.push('At least one activity must be selected.');
    } else if (selectedActivities.length === 1 && totalHours !== 6) {
      errors.push('If only one activity is selected, its hours must equal 6.');
    } else if (totalHours > 6) {
      errors.push('Total hours across all activities must not exceed 6.');
    }

    // Display errors in snackbar
    if (errors.length > 0) {
      this.snackBar.open(errors.join('\n'), 'Close', {
        duration: 5000,
        panelClass: 'error-snackbar',
      });
      return false;
    }

    return true;
  }

  resetForm(): void {
    this.logSheetForm.reset({
      logDate: this.today,
      dateStamp: this.today,
    });
    this.selectedStudentSignature = null;
  }

  goBack(): void {
    window.history.back();
  }
}
