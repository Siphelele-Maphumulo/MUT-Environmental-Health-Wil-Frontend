import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../../../services/auth.service';
import { ReactiveFormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-update-logsheet',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
  ],
  templateUrl: './update-logsheet.component.html',
  styleUrls: ['./update-logsheet.component.scss'],
})
export class UpdateLogsheetComponent implements OnInit {
  logSheetForm!: FormGroup;
  submissionMessage: string = '';
  today: string = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
  selectedStudentSignature: File | null = null;
  studentNumber: string | null = null;
  isFromStudentDashboard: boolean = false;
  existingLogsheetData: any = null;
  isUpdating: boolean = false;
  existingSignatureUrl: string | null = null;

  activities = [
    { name: 'Food Control' },
    { name: 'Monitoring water quality and availability' },
    { name: 'Waste Management' },
    { name: 'General hygiene monitoring' },
    { name: 'Vector control monitoring' },
    { name: 'Chemical safety' },
    { name: 'Noise control Hour' },
    { name: 'Environmental pollution control (water & air)' },
    { name: 'Radiation monitoring and control ' },
    { name: 'Health surveillance of premises' },
    {
      name: 'Surveillance & prevention of communicable diseases and Malaria control ',
    },
    { name: 'Port health (air, land and seaports)' },
    { name: 'Control & monitoring of hazardous substances' },
    { name: 'Disposal of the dead' },
  ];
  selectedActivitiesCount: any;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router,
    private sanitizer: DomSanitizer // Add this for signature URL sanitization
  ) {}

  ngOnInit(): void {
    const navigationState = history.state;
    this.isFromStudentDashboard = navigationState?.from === 'student-dashboard';
    this.studentNumber =
      navigationState?.studentNumber || this.authService.getStudentNumber();

    // Initialize form
    this.initializeForm();

    // Check for existing logsheet and load data
    this.loadExistingLogsheet();
  }

  private initializeForm(): void {
    this.logSheetForm = this.fb.group({
      logDate: [this.today],
      studentNumber: ['', Validators.required],
      description: ['', Validators.required],
      situationDescription: ['', Validators.required],
      situationEvaluation: ['', Validators.required],
      situationInterpretation: ['', Validators.required],
      studentSignature: [''],
      dateStamp: [this.today],
    });

    if (this.studentNumber) {
      this.logSheetForm.get('studentNumber')?.setValue(this.studentNumber);
    }

    // Add activity controls
    for (let i = 1; i <= 14; i++) {
      this.addActivityControls(i);
    }
  }

  private addActivityControls(index: number): void {
    const activityKey = `activity${index}`;
    const hoursKey = `hours${index}`;

    this.logSheetForm.addControl(activityKey, this.fb.control(false));
    this.logSheetForm.addControl(
      hoursKey,
      this.fb.control({ value: 0, disabled: true }, [
        Validators.min(0),
        Validators.max(6),
      ])
    );

    this.logSheetForm.get(activityKey)?.valueChanges.subscribe((checked) => {
      const hoursControl = this.logSheetForm.get(hoursKey);
      checked ? hoursControl?.enable() : hoursControl?.disable();
      if (!checked) hoursControl?.setValue(0);
    });
  }

  private loadExistingLogsheet(): void {
    if (!this.studentNumber) return;

    // Format the date properly for the API call
    const formattedDate = this.today; // or format it if needed

    this.authService
      .getLogsheetByDate(this.studentNumber, formattedDate)
      .subscribe({
        next: (response) => {
          if (response) {
            this.existingLogsheetData = response;
            this.populateFormWithExistingData();
            this.isUpdating = true;
            this.snackBar.open(
              'Loaded existing logsheet for editing.',
              'Close',
              {
                duration: 3000,
                panelClass: 'success-snackbar',
              }
            );
          } else {
            this.snackBar.open(
              'No existing logsheet found for today. Creating new one.',
              'Close',
              {
                duration: 3000,
              }
            );
            this.router.navigate(['/logsheet']);
          }
        },
        error: (error) => {
          if (error.status === 404) {
            this.snackBar.open(
              'No existing logsheet found for today. Creating new one.',
              'Close',
              {
                duration: 3000,
              }
            );
          } else {
            console.error('Error loading logsheet:', error);
            this.router.navigate(['/logsheet']);
            this.snackBar.open(
              'Error loading existing logsheet. Starting with blank form.',
              'Close',
              {
                duration: 5000,
              }
            );
          }
        },
      });
  }

  private populateFormWithExistingData(): void {
    if (!this.existingLogsheetData) return;

    // Set basic fields
    this.logSheetForm.patchValue({
      description: this.existingLogsheetData.description,
      situationDescription: this.existingLogsheetData.situation_description,
      situationEvaluation: this.existingLogsheetData.situation_evaluation,
      situationInterpretation:
        this.existingLogsheetData.situation_interpretation,
    });

    // Set activity checkboxes and hours
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activityName = this.existingLogsheetData[activityKey];

      if (activityName) {
        this.logSheetForm.get(activityKey)?.setValue(true);
        this.logSheetForm
          .get(hoursKey)
          ?.setValue(this.existingLogsheetData[hoursKey]);
      }
    }

    // Load existing signature if it exists
    if (this.existingLogsheetData.student_signature) {
      this.loadExistingSignature(this.existingLogsheetData.student_signature);
    }
  }

  private loadExistingSignature(signatureFilename: string): void {
    this.authService.getSignatureFile(signatureFilename).subscribe({
      next: (response) => {
        // Create a safe URL for the signature image
        const blob = new Blob([response], { type: 'image/png' });
        const url = URL.createObjectURL(blob);
        this.existingSignatureUrl = this.sanitizer.bypassSecurityTrustUrl(
          url
        ) as string;
      },
      error: (error) => {
        console.error('Error loading signature:', error);
        this.existingSignatureUrl = null;
      },
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedStudentSignature = input.files[0];
    }
  }

  onSubmit(): void {
    if (!this.validateForm()) {
      return;
    }

    if (this.isUpdating) {
      this.updateLogsheet();
    } else {
      this.submitLogsheet();
    }
  }

  private updateLogsheet(): void {
    const formData = new FormData();
    const formValue = this.logSheetForm.value;

    // Add form data with correct field names (snake_case)
    formData.append('log_date', formValue.logDate);
    formData.append('student_number', formValue.studentNumber);

    // Add individual activity fields
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey]
        ? this.activities[i - 1].name
        : null;
      const hours = formValue[hoursKey] || null;

      formData.append(activityKey, activity || '');
      formData.append(hoursKey, hours?.toString() || '');
    }

    formData.append('description', formValue.description);
    formData.append('situation_description', formValue.situationDescription);
    formData.append('situation_evaluation', formValue.situationEvaluation);
    formData.append(
      'situation_interpretation',
      formValue.situationInterpretation
    );
    formData.append('date_stamp', formValue.dateStamp);

    // Add files only if a new one was selected
    if (this.selectedStudentSignature) {
      formData.append('student_signature', this.selectedStudentSignature);
    } else if (this.existingLogsheetData?.student_signature) {
      // Keep the existing signature if no new one was provided
      formData.append(
        'student_signature',
        this.existingLogsheetData.student_signature
      );
    }

    this.authService;
    this.authService.update1Logsheet(formData).subscribe({
      next: (response) => {
        this.snackBar.open('Log sheet updated successfully!', 'Close', {
          duration: 3000,
          panelClass: 'success-snackbar',
        });
        if (this.isFromStudentDashboard) {
          this.router.navigate(['/student-dashboard']);
        }
      },
      error: (error) => {
        console.error('Update error:', error);
        this.snackBar.open(
          error.error?.message || 'Failed to update log sheet',
          'Close',
          { duration: 3000 }
        );
      },
    });
  }

  private submitLogsheet(): void {
    const formData = new FormData();
    const formValue = this.logSheetForm.value;

    // Add form data with correct field names (snake_case)
    formData.append('log_date', formValue.logDate);
    formData.append('student_number', formValue.studentNumber);
    formData.append('EHP_HI_Number', 'Not Signed');

    // Add individual activity fields
    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey]
        ? this.activities[i - 1].name
        : null;
      const hours = formValue[hoursKey] || null;

      formData.append(activityKey, activity || '');
      formData.append(hoursKey, hours?.toString() || '');
    }

    formData.append('description', formValue.description);
    formData.append('situation_description', formValue.situationDescription);
    formData.append('situation_evaluation', formValue.situationEvaluation);
    formData.append(
      'situation_interpretation',
      formValue.situationInterpretation
    );
    formData.append('date_stamp', formValue.dateStamp);

    // Add files
    if (this.selectedStudentSignature) {
      formData.append('student_signature', this.selectedStudentSignature);
    }

    this.authService.createLogSheet(formData).subscribe({
      next: (response) => {
        this.snackBar.open('Log sheet submitted successfully!', 'Close', {
          duration: 3000,
          panelClass: 'success-snackbar',
        });
        this.resetForm();
      },
      error: (error) => {
        console.error('Submission error:', error);
        this.snackBar.open(
          error.error?.message || 'Failed to submit log sheet',
          'Close',
          { duration: 3000 }
        );
      },
    });
  }

  limitSelection(event: any): void {
    const isChecked = event.target.checked;
    const index = event.target.name.replace('activity', '');
    const hoursControl = this.logSheetForm.get(`hours${index}`);

    if (isChecked) {
      this.selectedActivitiesCount++;
      if (this.selectedActivitiesCount > 6) {
        this.snackBar.open('You can only select up to 6 activities.', 'Close', {
          duration: 3000,
        });
        event.target.checked = false;
        this.selectedActivitiesCount--;
      } else {
        hoursControl?.enable();
      }
    } else {
      this.selectedActivitiesCount--;
      hoursControl?.disable();
    }
  }

  validateForm(): boolean {
    const formValue = this.logSheetForm.value;
    const errors: string[] = [];

    // Validate required fields
    if (!formValue.studentNumber?.trim()) {
      errors.push('Student number is required.');
    }
    if (!formValue.description?.trim()) {
      errors.push('Description of WIL activities is required.');
    }
    if (!formValue.situationDescription?.trim()) {
      errors.push('Situation description is required.');
    }
    if (!formValue.situationEvaluation?.trim()) {
      errors.push('Situation evaluation is required.');
    }
    if (!formValue.situationInterpretation?.trim()) {
      errors.push('Situation interpretation is required.');
    }
    if (!this.hasValidSignature()) {
      errors.push('Student signature is required.');
    }

    // Validate activities
    const selectedActivities = [];
    let totalHours = 0;
    let hasActivityWithoutHours = false;

    for (let i = 1; i <= 14; i++) {
      const activityKey = `activity${i}`;
      const hoursKey = `hours${i}`;
      const activity = formValue[activityKey];
      const hours = formValue[hoursKey];

      if (activity) {
        selectedActivities.push(this.activities[i - 1].name);
        if (!hours || hours <= 0) {
          hasActivityWithoutHours = true;
          errors.push(
            `Hours must be allocated for activity "${
              this.activities[i - 1].name
            }".`
          );
        }
        totalHours += hours || 0;
      }
    }

    if (selectedActivities.length === 0) {
      errors.push('At least one activity must be selected.');
    } else if (selectedActivities.length === 1 && totalHours !== 6) {
      errors.push('If only one activity is selected, its hours must equal 6.');
    } else if (totalHours > 6) {
      errors.push('Total hours across all activities must not exceed 6.');
    } else if (hasActivityWithoutHours) {
      // This message is already included in the individual activity errors
    }

    // Display errors in snackbar
    if (errors.length > 0) {
      this.snackBar.open(errors.join('\n'), 'Close', {
        duration: 5000,
        panelClass: 'error-snackbar',
      });
      return false;
    }

    return true;
  }

  private hasValidSignature(): boolean {
    // Signature is valid if either:
    // 1. A new file was selected, OR
    // 2. There's an existing signature from the loaded logsheet
    return (
      !!this.selectedStudentSignature ||
      !!this.existingLogsheetData?.student_signature
    );
  }

  resetForm(): void {
    this.logSheetForm.reset({
      logDate: this.today,
      dateStamp: this.today,
    });
    this.selectedStudentSignature = null;
  }

  goBack(): void {
    window.history.back();
  }
}
