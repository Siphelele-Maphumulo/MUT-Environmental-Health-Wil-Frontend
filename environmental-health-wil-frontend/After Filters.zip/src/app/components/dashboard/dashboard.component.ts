import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-dashboard',
    imports: [
        MatSidenavModule,
        MatListModule,
        MatIconModule,
        MatCardModule,
        MatButtonModule,
        MatToolbarModule,
        RouterModule,
        CommonModule
    ],
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dashboardData: any;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    // this.fetchDashboardData();
  }

  // Fetch data via the DataService
  // fetchDashboardData(): void {
  //   this.dataService.getDashboardData().subscribe({
  //     next: (data) => {
  //       this.dashboardData = data;
  //       console.log('Dashboard data:', data);
  //     },
  //     error: (err) => {
  //       console.error('Error fetching dashboard data', err);
  //     }
  //   });
  // }
}
