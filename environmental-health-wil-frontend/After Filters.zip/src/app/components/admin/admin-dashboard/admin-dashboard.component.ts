import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {
  faHome,
  faFileAlt,
  faClipboardList,
  faBook,
  faUser,
  faChalkboardTeacher,
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-admin-dashboard',
  imports: [MatToolbarModule, CommonModule, RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss'],
})
export class AdminDashboardComponent {
  applicationCard: string = 'Application';
  // Add other components cards

  faHome = faHome;
  faFileAlt = faFileAlt;
  faClipboardList = faClipboardList;
  faBook = faBook;
  faUser = faUser;
  faChalkboardTeacher = faChalkboardTeacher;

  // Method to refresh the page
  refreshPage(): void {
    window.location.reload();
  }

  openChatbot(): void {
    console.log('Chatbot button clicked');
    // Add logic to open the chatbot here
  }
}
