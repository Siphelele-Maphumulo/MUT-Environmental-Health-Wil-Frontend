import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms'; // Import FormsModule

@Component({
    selector: 'app-pin-dialog',
    template: `
    <h1 mat-dialog-title>Enter Event Pin</h1>
    <div mat-dialog-content>
      <mat-form-field appearance="fill" style="width: 150%;">
        <mat-label>Pin Code</mat-label>
        <input matInput [(ngModel)]="pinCode" type="password" />
      </mat-form-field>
    </div>
    <div mat-dialog-actions>
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-button color="primary" (click)="onSubmit()">Submit</button>
    </div>
  `,
    imports: [MatFormFieldModule, MatInputModule, MatButtonModule, FormsModule]
})
export class PinDialogComponent {
  pinCode: string = '';

  constructor(private dialogRef: MatDialogRef<PinDialogComponent>) {}

  onCancel(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    this.dialogRef.close(this.pinCode); // Pass the entered pin code back
  }
}
