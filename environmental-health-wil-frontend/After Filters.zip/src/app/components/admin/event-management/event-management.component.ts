import { Component } from '@angular/core';
import { MatDialog, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { PinDialogComponent } from './pin-dialog/pin-dialog.component'; // Correct the path based on your file structure

@Component({
    selector: 'app-event-management',
    templateUrl: './event-management.component.html',
    styleUrls: ['./event-management.component.scss'],
    imports: [
        MatToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSelectModule,
        MatIconModule,
        MatDialogModule,
        CommonModule,
    ]
})
export class EventManagementComponent {
  selectedFileName: string | null = null;

  constructor(private dialog: MatDialog, private router: Router) {}

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFileName = input.files[0].name;
      console.log('File selected:', input.files[0]);
    }
  }

  openPinDialog(): void {
    const dialogRef = this.dialog.open(PinDialogComponent, {
      width: '300px',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === '2024') {
        this.router.navigate(['/home']); // Navigate to home page if pin is correct
      } else {
        alert('Invalid Pin Code'); // Alert for incorrect pin
      }
    });
  }
}
