export interface WilReport {
}
