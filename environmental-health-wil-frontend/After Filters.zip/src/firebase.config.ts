export const firebaseConfig = {
  apiKey: "AIzaSyArGQJe-SQuL9ZQf7BRlfFn_TfzEFczuac",
  authDomain: "environmentalhealth-74184.firebaseapp.com",
  projectId: "environmentalhealth-74184",
  storageBucket: "environmentalhealth-74184.appspot.com",
  messagingSenderId: "74015019496",
  appId: "1:74015019496:web:b30de39dc4206b3df2145d"
};
