import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatToolbarModule } from '@angular/material/toolbar';
import { faTurkishLiraSign } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-reflections',
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatInputModule,
    ReactiveFormsModule,
  ],
  templateUrl: './reflections.component.html',
  styleUrls: ['./reflections.component.scss'],
})
export class ReflectionsComponent implements OnInit {
  reflectionForm: FormGroup;
  studentNumber: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private router: Router
  ) {
    // Initialize form with empty values
    this.reflectionForm = this.fb.group({
      studentNumber: ['', Validators.required],
      studentName: ['', Validators.required],
      feeling: ['', Validators.required],
      success: ['', Validators.required],
      challenges: ['', Validators.required],
      perspectiveChange: ['', Validators.required],
      suggestions: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    const navigation = window.history.state;
    const studentNumber = navigation?.studentNumber;

    if (!studentNumber) {
      this.showError('Student number not found.');
      return;
    }

    this.loadStudentDetails(studentNumber);
    this.loadExistingReflection(studentNumber); // 👈 Pre-fill if data exists
  }

  loadStudentDetails(studentNumber: string): void {
    const url = `http://localhost:8080/api/student/${studentNumber}`;

    this.http.get<{ fullName: string }>(url).subscribe({
      next: (res) => {
        console.log('Student name loaded:', res.fullName);
        this.reflectionForm.patchValue({
          studentNumber,
          studentName: res.fullName,
        });
      },
      error: (err) => {
        console.error('Error loading student details:', err);
        this.showError('Failed to load student name');
      },
    });
  }

  loadExistingReflection(studentNumber: string): void {
    const url = `http://localhost:8080/api/reflection/${studentNumber}`;

    this.http.get<any>(url).subscribe({
      next: (res) => {
        const formatted = {
          studentNumber: res.student_number,
          studentName: res.student_name,
          feeling: res.feeling,
          success: res.success,
          challenges: res.challenges,
          perspectiveChange: res.perspective_change,
          suggestions: res.suggestions,
        };
        this.reflectionForm.patchValue(formatted);
      },
      error: (err) => {
        console.log(
          'No existing reflection found, proceeding with empty form.'
        );
      },
    });
  }

  submitReflection(): void {
    if (this.reflectionForm.invalid) {
      this.showError('Please fill in all required fields before submitting.');
      return;
    }

    const formValue = this.reflectionForm.value;

    this.http
      .post('http://localhost:8080/api/submit-reflection', formValue)
      .subscribe({
        next: (response) => {
          this.showSuccess('Reflection submitted successfully!');
          this.reflectionForm.reset();
        },
        error: (err) => {
          console.error('Submission error:', err);
          this.showError('Failed to submit reflection. Please try again.');
        },
      });
  }

  clear(): void {
    this.reflectionForm.reset();
    console.info('Form cleared');
  }

  hasError(controlName: string): boolean {
    const control = this.reflectionForm.get(controlName);
    return !!(control && control.invalid && control.touched);
  }

  private showSuccess(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar'],
    });
  }

  private showError(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 5000,
      panelClass: ['error-snackbar'],
    });
  }
}
