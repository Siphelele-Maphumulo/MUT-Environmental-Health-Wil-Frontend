import { Component, OnInit } from '@angular/core';
import { ChartConfiguration, ChartData, ChartType } from 'chart.js';
import { NgChartsModule } from 'ng2-charts';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { AnalyticsService } from '../../services/analytics.service';

@Component({
  selector: 'app-analytics-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    NgChartsModule,
    MatCardModule,
    MatGridListModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatFormFieldModule,
    FormsModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './analytics-dashboard.component.html',
  styleUrls: ['./analytics-dashboard.component.scss']
})
export class AnalyticsDashboardComponent implements OnInit {
  loading = true;
  timeRange = '30days'; // Default time range
  startDate: Date;
  endDate: Date;

  // Chart configurations
  applicationsChart: ChartConfiguration['data'] = {
    datasets: [],
    labels: []
  };
  applicationsOptions: ChartConfiguration['options'] = {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'WIL Applications Status'
      }
    }
  };

  logsheetsChart: ChartData<'bar'> = {
    labels: [],
    datasets: []
  };

  attendanceChart: ChartData<'pie'> = {
    labels: [],
    datasets: []
  };

  placementsMapData: any[] = [];
  studentProgressData: any[] = [];
  systemActivityData: any[] = [];

  constructor(private analyticsService: AnalyticsService) {
    const today = new Date();
    this.endDate = today;
    this.startDate = new Date(today.setDate(today.getDate() - 30));
  }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading = true;
    this.analyticsService.getDashboardData(this.timeRange, this.startDate, this.endDate).subscribe({
      next: (data) => {
        this.processData(data);
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading analytics data:', error);
        this.loading = false;
      }
    });
  }

  processData(data: any): void {
    // Process applications data
    this.applicationsChart = {
      labels: data.applications.statusLabels,
      datasets: [{
        data: data.applications.statusCounts,
        backgroundColor: ['#4CAF50', '#FFC107', '#F44336', '#2196F3'],
        label: 'Applications'
      }]
    };

    // Process logsheets data
    this.logsheetsChart = {
      labels: data.logsheets.monthlyLabels,
      datasets: [
        {
          label: 'Submitted Logsheets',
          data: data.logsheets.monthlyCounts,
          backgroundColor: '#3F51B5'
        }
      ]
    };

    // Process attendance data
    this.attendanceChart = {
      labels: ['Attended', 'Registered', 'No Show'],
      datasets: [{
        data: data.attendance.stats,
        backgroundColor: ['#4CAF50', '#FFC107', '#F44336']
      }]
    };

    // Process other data
    this.placementsMapData = data.placements;
    this.studentProgressData = data.studentProgress;
    this.systemActivityData = data.systemActivity;
  }

  onDateChange(): void {
    this.loadData();
  }

  onTimeRangeChange(): void {
    const today = new Date();
    this.endDate = today;
    
    switch(this.timeRange) {
      case '7days':
        this.startDate = new Date(today.setDate(today.getDate() - 7));
        break;
      case '30days':
        this.startDate = new Date(today.setDate(today.getDate() - 30));
        break;
      case '90days':
        this.startDate = new Date(today.setDate(today.getDate() - 90));
        break;
      case 'custom':
        // Keep current dates
        break;
    }
    
    this.loadData();
  }
}