import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {
  private apiUrl = 'http://localhost:8080/api/analytics';

  constructor(private http: HttpClient) { }

  getDashboardData(timeRange: string, startDate: Date, endDate: Date): Observable<any> {
    const params = {
      range: timeRange,
      start: startDate.toISOString().split('T')[0],
      end: endDate.toISOString().split('T')[0]
    };

    return this.http.get(`${this.apiUrl}/dashboard`, { params }).pipe(
      map(response => this.transformData(response))
    );
  }

  private transformData(rawData: any): any {
    // Transform raw API data into chart-ready format
    return {
      applications: {
        statusLabels: rawData.applications.map((item: any) => item.status),
        statusCounts: rawData.applications.map((item: any) => item.count)
      },
      logsheets: {
        monthlyLabels: rawData.logsheets.map((item: any) => item.month),
        monthlyCounts: rawData.logsheets.map((item: any) => item.count)
      },
      attendance: {
        stats: [
          rawData.attendance.attended,
          rawData.attendance.registered,
          rawData.attendance.noShow
        ]
      },
      placements: rawData.placements,
      studentProgress: rawData.studentProgress,
      systemActivity: rawData.systemActivity
    };
  }
}