import { YearFormatPipe } from './year-format.pipe';

describe('YearFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new YearFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
