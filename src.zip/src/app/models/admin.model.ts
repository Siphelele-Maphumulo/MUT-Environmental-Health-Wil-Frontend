export interface Admin {
}
