// src/environments/environment.ts
// export const environment = {
//   production: false,
//   apiUrl: 'http://localhost:8080/api/', // Update with your actual API base URL
// };
export const environment = {
  production: false,
  apiUrl: 'https://mut-wil-backend.onrender.com'
};
